require('dotenv').config()
const mysql = require('mysql2/promise');
const pool = mysql.createPool({
    host: process.env.DB_HOST,
    port: process.env.DB_PORT || 3306,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    //10 conexiones maximas
    connectionLimit:10,
    waitForConnections: true,
    queueLimit: 0
})

module.exports = pool;
import { useEffect, useRef, useState } from 'react';
import LineaTiempo from './LineaTiempo';
import { checkDuracion, cambiarDuracion } from '../utils/operacionesFrames';
import { esCampoDeTexto } from '../utils/atajosArte';
import { inicios, duracionTotal, indiceEnTiempo, formatearTiempo } from '../utils/lineaTiempo';

// Pestaña "Video": la animación en el tiempo. Vista previa, controles de reproducción y la línea de tiempo.
// Aquí la reproducción es continua (el cabezal avanza en milisegundos, no de frame en frame), para que
// más adelante los keyframes se puedan poner en cualquier momento.
//
// Props:
//   datos          lo que devuelve useProyectoFrames
//   reproduccion   lo que devuelve useReproduccion: se abre en el frame que se estaba viendo y se le avisa
//                  cada vez que cambia el frame, para que la pestaña Frames siga en el mismo
//   proporcion     "ancho / alto" del lienzo, para los frames en blanco
//   onEditar(clave)   abrir un frame en la pestaña Imagen (opcional)
function EtapaVideo({ datos, reproduccion, proporcion, onEditar }) {
    const { frames, aplicar, ocupado } = datos;
    const total = duracionTotal(frames);
    const [tiempo, setTiempo] = useState(() => inicios(frames)[reproduccion.indice] || 0);
    const [reproduciendo, setReproduciendo] = useState(false);

    // Si los frames se acortan, el cabezal no puede quedar después del final
    const tiempoSeguro = Math.min(tiempo, Math.max(total - 1, 0));
    const indice = indiceEnTiempo(frames, tiempoSeguro);
    const frame = frames[indice];

    // Reproducción continua: en cada cuadro de pantalla el cabezal avanza lo que pasó desde el anterior.
    // Al llegar al final vuelve al comienzo
    useEffect(() => {
        if (!reproduciendo || total <= 0) return undefined;
        let anterior = performance.now();
        let pedido;
        function avanzar(ahora) {
            const pasado = ahora - anterior;
            anterior = ahora;
            setTiempo((actual) => (Math.min(actual, total) + pasado) % total);
            pedido = requestAnimationFrame(avanzar);
        }
        pedido = requestAnimationFrame(avanzar);
        return () => cancelAnimationFrame(pedido);
    }, [reproduciendo, total]);

    // La pestaña Frames queda en el mismo frame que se ve aquí
    const { indice: indiceCompartido, irA } = reproduccion;
    useEffect(() => {
        if (indice !== indiceCompartido) irA(indice);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [indice]);

    // Mover el cabezal a mano detiene la reproducción
    function buscar(nuevo) {
        setReproduciendo(false);
        setTiempo(nuevo);
    }

    function irAFrame(nuevoIndice) {
        const limitado = Math.min(Math.max(nuevoIndice, 0), frames.length - 1);
        buscar(inicios(frames)[limitado]);
    }

    // Devuelve false si la duración no es válida
    function cambiarDuracionDeUno(clave, valor) {
        if (ocupado || !checkDuracion(valor)) return false;
        aplicar((f) => cambiarDuracion(f, [clave], valor));
        return true;
    }

    // Atajos de esta pestaña: espacio reproduce o pausa, las flechas cambian de frame,
    // Inicio y Fin van a los extremos, y Ctrl + Z / Y / S como en la pestaña Frames
    const acciones = useRef({});
    acciones.current = {
        alternar: () => setReproduciendo((actual) => !actual),
        anterior: () => irAFrame(indice - 1),
        siguiente: () => irAFrame(indice + 1),
        inicio: () => irAFrame(0),
        fin: () => irAFrame(frames.length - 1),
        deshacer: datos.deshacer,
        rehacer: datos.rehacer,
        guardar: datos.guardar,
    };
    useEffect(() => {
        function alPulsar(evento) {
            if (esCampoDeTexto(evento.target)) return;
            const a = acciones.current;
            const control = evento.ctrlKey || evento.metaKey;
            const tecla = evento.key.toLowerCase();
            const porTecla = {
                ' ': a.alternar,
                arrowleft: a.anterior,
                arrowright: a.siguiente,
                home: a.inicio,
                end: a.fin,
            };
            let accion = null;
            if (control && tecla === 'z' && !evento.shiftKey) accion = a.deshacer;
            else if (control && (tecla === 'y' || (tecla === 'z' && evento.shiftKey))) accion = a.rehacer;
            else if (control && tecla === 's') accion = a.guardar;
            else if (!control && !evento.altKey) accion = porTecla[tecla];
            if (!accion) return;
            evento.preventDefault();
            accion();
        }
        document.addEventListener('keydown', alPulsar);
        return () => document.removeEventListener('keydown', alPulsar);
    }, []);

    if (frames.length === 0) {
        return <p>Este proyecto todavía no tiene frames. Ve a la pestaña Importar para subir un GIF.</p>;
    }

    const nombre = `Frame ${indice + 1} de ${frames.length}`;
    return (
        <section className="etapa-video" aria-labelledby="titulo-video">
            <h2 id="titulo-video">Video</h2>

            {frame.vacio ? (
                <div
                    className="frame-vacio vista-previa"
                    role="img"
                    aria-label={`${nombre} (en blanco)`}
                    style={proporcion ? { aspectRatio: proporcion } : undefined}
                >
                    En blanco
                </div>
            ) : (
                <img className="vista-previa" src={frame.imagen} alt={nombre} />
            )}

            <div className="controles-video">
                <button type="button" onClick={() => irAFrame(0)} aria-label="Ir al inicio" title="Ir al inicio (Inicio)">⏮</button>
                <button type="button" onClick={() => irAFrame(indice - 1)} aria-label="Frame anterior" title="Frame anterior (←)">◀</button>
                <button type="button" className="boton-reproducir" onClick={acciones.current.alternar} title="Reproducir o pausar (Espacio)">
                    {reproduciendo ? 'Pausar' : 'Reproducir'}
                </button>
                <button type="button" onClick={() => irAFrame(indice + 1)} aria-label="Frame siguiente" title="Frame siguiente (→)">▶</button>
                <span className="tiempo-video">
                    {formatearTiempo(tiempoSeguro)} / {formatearTiempo(total)} · {nombre} · {frame.duracion} ms
                </span>
            </div>

            <LineaTiempo
                frames={frames}
                tiempo={tiempoSeguro}
                indiceActual={indice}
                seguir={reproduciendo}
                bloqueada={ocupado}
                onBuscar={buscar}
                onDuracion={cambiarDuracionDeUno}
                onEditar={onEditar}
            />
            {/* Los cambios de duración hechos aquí se deshacen y se guardan igual que en la pestaña Frames */}
            <div className="estado-video">
                <button type="button" onClick={datos.deshacer} disabled={ocupado || !datos.puedeDeshacer}>Deshacer</button>
                <button type="button" onClick={datos.rehacer} disabled={ocupado || !datos.puedeRehacer}>Rehacer</button>
                <button type="button" onClick={datos.guardar} disabled={ocupado || !datos.sinGuardar}>
                    {datos.guardando ? 'Guardando...' : 'Guardar'}
                </button>
                <span className={datos.sinGuardar ? 'estado-sin-guardar' : 'estado-guardado'}>
                    {datos.sinGuardar ? 'Hay cambios sin guardar' : 'Todo guardado'}
                </span>
            </div>
            <p className="ayuda-video">
                Clic en la regla o en un frame para ir a ese momento. Arrastra el borde derecho de un frame para cambiar su
                duración. Doble clic en un frame para editarlo.
            </p>
        </section>
    );
}

export default EtapaVideo;
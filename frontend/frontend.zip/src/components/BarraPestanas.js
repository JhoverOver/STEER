// Barra vertical de etapas del proyecto, a la izquierda de la pantalla durante todo el proyecto:
// importación, edición de frames, edición de imagen y edición de video (Incremento 3).
// Hoy solo reserva el lugar; las pestañas se agregarán aquí sin tocar el resto de la pantalla.
function BarraPestanas() {
    return <nav className="barra-pestanas" aria-label="Etapas del proyecto" />;
}

export default BarraPestanas;